from Repositorios.InterfaceRepositorio import InterfaceRepositorio
from Modelos.Partido import Partido
class RepositorioPartido(InterfaceRepositorio[Partido]):
    pass