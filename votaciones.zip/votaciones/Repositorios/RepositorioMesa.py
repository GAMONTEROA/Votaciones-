from Repositorios.InterfaceRepositorio import InterfaceRepositorio
from Modelos.Mesa import Mesa
class RepositorioMesa(InterfaceRepositorio[Mesa]):
    pass